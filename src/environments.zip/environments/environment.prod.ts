export const environment = {
  production: true,
  apiKey:'',
  baseUrl: 'https://staging.ekarigar.com/kaam-chor',
  images: ''
};
